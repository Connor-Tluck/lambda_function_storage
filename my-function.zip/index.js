const fs = require("fs");
const { Configuration, OpenAIApi } = require("openai");
const { createClient } = require("@supabase/supabase-js");
const AWS = require("aws-sdk");

require("dotenv").config({ path: __dirname + '/.env' });

const s3 = new AWS.S3();

const generateEmbeddings = async (essays, databaseName) => {
  const configuration = new Configuration({
    apiKey: process.env.OPENAI_API_KEY,
  });
  const openai = new OpenAIApi(configuration);

  const supabase = createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL,
    process.env.SUPABASE_SERVICE_ROLE_KEY
  );

  console.log("Supabase Connection Info:");
  console.log("URL:", process.env.NEXT_PUBLIC_SUPABASE_URL);
  console.log("Key:", process.env.SUPABASE_SERVICE_ROLE_KEY);

  for (let i = 0; i < essays.length; i++) {
    const section = essays[i];

    for (let j = 0; j < section.chunks.length; j++) {
      const chunk = section.chunks[j];

      const {
        essay_title,
        essay_url,
        essay_date,
        essay_thanks,
        content,
        content_length,
        content_tokens,
      } = chunk;

      console.log("Processing chunk:", i, j);
      console.log("Content:", content);

      const embeddingResponse = await openai.createEmbedding({
        model: "text-embedding-ada-002",
        input: content,
      });

      const [{ embedding }] = embeddingResponse.data.data;

      console.log("Embedding:", embedding);

      const { data, error } = await supabase
        .from(databaseName)
        .insert({
          essay_title,
          essay_url,
          essay_date,
          essay_thanks,
          content,
          content_length,
          content_tokens,
          embedding,
        })
        .select("*");

      if (error) {
        console.log("Error saving to Supabase:", error);
      } else {
        console.log("Saved to Supabase:", i, j);
      }

      await new Promise((resolve) => setTimeout(resolve, 200));
    }
  }
};

exports.handler = async (event, context) => {
  try {
    const bucket = event.Records[0].s3.bucket.name;
    const key = decodeURIComponent(
      event.Records[0].s3.object.key.replace(/\+/g, " ")
    );

    console.log("Processing JSON file:", key);

    const getObjectParams = {
      Bucket: bucket,
      Key: key,
    };

    const file = await s3.getObject(getObjectParams).promise();

    const book = JSON.parse(file.Body.toString("utf-8"));

    const databaseName = process.env.DATABASE_NAME || "pg"; // Set your Supabase database name here

    console.log("Processing book:", book);

    await generateEmbeddings(book.essays, databaseName);

    console.log("Processing completed");

    return {
      statusCode: 200,
      body: "Processing completed",
    };
  } catch (error) {
    console.error("Error processing JSON:", error);
    return {
      statusCode: 500,
      body: "Error processing JSON",
    };
  }
};
